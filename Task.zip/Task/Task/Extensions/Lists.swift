//
//  Lists.swift
//  Task
//
//  Created by ibrahem on 24/07/2022.
//

import UIKit.UITableView
import UIKit.UICollectionView
import UIKit

// MARK: - Naming
protocol Naming { }
extension Naming {
    func name(of className: AnyClass) -> String {
        return String.init(describing: className)
    }
}

// MARK:- TABLE VIEW
extension UITableView: Naming {
    
    func register<Cell: UITableViewCell>(_ type: Cell.Type) {
        let id = name(of: type)
        let nib: UINib = .init(nibName: id, bundle: .none)
        register(nib, forCellReuseIdentifier: id)
    }
    
    func dequeue<Cell: UITableViewCell>(_ type: Cell.Type, for indexPath: IndexPath) -> Cell {
        let id = name(of: type)
        guard let cell = dequeueReusableCell(withIdentifier: id, for: indexPath) as? Cell else {
            fatalError("You must pass cell name like as cell id = \(id)")
        }
        return cell
    }
    
    func setNoDataView(with message: String = "", for state: Bool,color:UIColor? = .black) {
        self.backgroundView = .init()
        self.backgroundView?.background(self.backgroundColor ?? .white)
        // self.background(.clear)
        let imageView = UIImageView(image: UIImage(named: "") ?? .init())
        imageView.contentMode = .scaleAspectFit
        imageView.tint(UIColor.init(hexString: mainColor))
        let lbl = Label()
        lbl.alignment(.center)
        lbl.numberOfLines = .zero
        lbl.adjustsFontSizeToFitWidth = true
        lbl.minimumScaleFactor = 0.6
        lbl.textColor = color
        lbl.text(message)
        let stk = UIStackView(arrangedSubviews: [imageView, lbl])
        stk.alignment = .center
        stk.distribution = .fill
        stk.axis = .vertical
        stk.spacing = .zero
        if state {
            let dimension = bounds.size.width * 0.3
            imageView.setDimensions(.init(width: dimension, height: dimension / 2))
            self.backgroundView?.add(stk)
            stk.putInCenter(at: .vertical)
                .align(a: .leading, to: self.backgroundView!.leadingAnchor)
                .align(a: .trailing, to: self.backgroundView!.trailingAnchor)
        } else {
            stk.removeFromSuperview()
        }
    }
    
    func createRefresher() {
        refreshControl = UIRefreshControl()
        refreshControl?.tintColor = UIColor.init(hexString: mainColor)
    }
    
}

// MARK:- COLLECTION VIEW

extension UICollectionView: Naming {
    
    func register<Cell: UICollectionViewCell>(_ type: Cell.Type) {
        let id = name(of: type)
        let nib: UINib = .init(nibName: id, bundle: .none)
        register(nib, forCellWithReuseIdentifier: id)
    }
    
    func dequeue<Cell: UICollectionViewCell>(_ type: Cell.Type, for indexPath: IndexPath) -> Cell {
        let cellName = name(of: type)
        guard let cell = dequeueReusableCell(withReuseIdentifier: cellName, for: indexPath) as? Cell else {
            fatalError("You must set cell name as like controller name to be \(cellName) or something else.")
        }
        return cell
    }
    
    func dequeue<Cell: UICollectionReusableView>(_ type: Cell.Type,
                                                 of kind: String,
                                                 for indexPath: IndexPath) -> Cell {
        let name = self.name(of: type)
        guard let cell = dequeueReusableSupplementaryView(
            ofKind: kind,
            withReuseIdentifier: name,
            for: indexPath
            ) as? Cell else {
                fatalError("You must set cell name as like controller name to be \(name) or something else.")
        }
        return cell
    }
    
    func setNoDataView(with message: String = "", for state: Bool) {
        self.backgroundView = .init()
        self.backgroundView?.background(self.backgroundColor ?? .white)
        // self.background(.clear)
        let imageView = UIImageView(image: UIImage(named: "") ?? .init())
        imageView.tint(UIColor.init(hexString: mainColor))
        imageView.contentMode = .scaleAspectFit
        let lbl = Label()
        lbl.insets = .zero
        lbl.alignment(.center)
        lbl.numberOfLines = .zero
        lbl.adjustsFontSizeToFitWidth = true
        lbl.minimumScaleFactor = 0.6
        lbl.text(message)
        let stk = UIStackView(arrangedSubviews: [imageView, lbl])
        stk.alignment = .center
        stk.distribution = .fill
        stk.axis = .vertical
        stk.spacing = .zero
        if state {
            let dimension = bounds.size.width * 0.3
            imageView.setDimensions(.init(width: dimension, height: dimension / 2))
            self.backgroundView?.add(stk)
            stk.putInCenter(at: .vertical)
                .align(a: .leading, to: self.backgroundView!.leadingAnchor)
                .align(a: .trailing, to: self.backgroundView!.trailingAnchor)
        } else {
            stk.removeFromSuperview()
        }
    }
    
    func createRefresher() {
        refreshControl = UIRefreshControl()
        refreshControl?.tintColor = UIColor.init(hexString: mainColor)
    }
}

