//
//  Colors.swift
//  Task
//
//  Created by ibrahem on 24/07/2022.
//

import Foundation
import UIKit.UIColor
let mainColor = "3A1B50"

extension UIColor {
    
    /*convenience init(hex: String, with alpha: CGFloat = 1) {
        let hexString = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        let scanner = Scanner(string: hexString)
        if hexString.hasPrefix("#") {
            scanner.scanLocation = 1
        }
        var color: UInt32 = 0
        scanner.scanHexInt32(&color)
        let mask = 0x000000FF
        let red = CGFloat((Int(color >> 16) & mask)) / 255.0
        let green = CGFloat((Int(color >> 8) & mask)) / 255.0
        let blue = CGFloat((Int(color) & mask)) / 255.0
        // let alpha = CGFloat(Int(color) & mask) / 255.0
        self.init(red: red, green: green, blue: blue, alpha: alpha)
    }*/
    
    @objc convenience init(hexString:String) {
        let scanner  = Scanner(string: hexString.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines))
        
        if (hexString.hasPrefix("#")) {
            scanner.scanLocation = 1
        }
        
        var color:UInt32 = 0
        scanner.scanHexInt32(&color)
        
        let mask = 0x000000FF
        let r = Int(color >> 16) & mask
        let g = Int(color >> 8) & mask
        let b = Int(color) & mask
        
        let red   = CGFloat(r) / 255.0
        let green = CGFloat(g) / 255.0
        let blue  = CGFloat(b) / 255.0
        
        self.init(red:red, green:green, blue:blue, alpha:1)
    }
    
}
