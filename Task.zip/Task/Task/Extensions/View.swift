//
//  View.swift
//  Task
//
//  Created by ibrahem on 24/07/2022.
//

import Foundation
import UIKit.UIView
// pecker:ignore all
extension UIView {
    var midHeight: CGFloat {
        return bounds.size.height * 0.50
    }
    
    typealias AxisMargin = CGPoint
    enum Dimensions {
        case width, height
    }
    enum HorizontalAxis {
        case right, left, leading, trailing
    }
    enum VerticalAxis {
        case top, bottom
    }
    enum RespectDirection {
        case respect, unrespect
    }
    struct Accessories {
        let multiplier: CGFloat
        let constant: CGFloat
        static var zero: Accessories {
            return Accessories(multiplier: 1.0, constant: 0)
        }
    }
    
    ///Set views in view
    @discardableResult
    func add(_ views: UIView...) -> Self {
        views.forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            addSubview($0)
        }
        return self
    }
    
    /// Fill view in super view
    @discardableResult
    func fill(_ margin: UIEdgeInsets = .zero, _ directionRespect: RespectDirection = .respect) -> Self? {
        precondition(superview != nil, "Must add target view in a container view.")
        guard case let .some(container) = superview else { return nil }
        topAnchor.constraint(equalTo: container.topAnchor, constant: margin.top)
            .isActive = true
        bottomAnchor.constraint(equalTo: container.bottomAnchor, constant: -margin.bottom)
            .isActive = true
        switch directionRespect {
            case .unrespect:
                leftAnchor.constraint(equalTo: container.leftAnchor, constant: margin.left)
                    .isActive = true
                rightAnchor.constraint(equalTo: container.rightAnchor, constant: -margin.right)
                    .isActive = true
            case .respect:
                leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: margin.left)
                    .isActive = true
                trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -margin.right)
                    .isActive = true
        }
        return self
    }
    
    /// Set view in middle
    @discardableResult
    func putInCenter(_ margin: AxisMargin = .zero) -> Self {
        precondition(superview != nil, "Must add target view in a container view.")
        guard case .some(let containter) = superview else { return self }
        NSLayoutConstraint.activate([
            centerXAnchor.constraint(equalTo: containter.centerXAnchor, constant: margin.x),
            centerYAnchor.constraint(equalTo: containter.centerYAnchor, constant: margin.y)
        ])
        return self
    }
    
    @discardableResult
    func putInCenter(at axis: NSLayoutConstraint.Axis, _ margin: CGFloat = 0.0) -> Self {
        precondition(superview != nil, "Must add target view in a container view.")
        guard case .some(let containter) = superview else { return self }
        switch axis {
            case .horizontal:
                centerXAnchor.constraint(equalTo: containter.centerXAnchor, constant: margin).isActive = true
            case .vertical:
                centerYAnchor.constraint(equalTo: containter.centerYAnchor, constant: margin).isActive = true
            @unknown default:
                print(#function, "can't set constaint")
                break
        }
        return self
    }
    
    @discardableResult
    func setDimensions(_ dimensions: CGSize) -> Self {
        NSLayoutConstraint.activate([
            widthAnchor.constraint(equalToConstant: dimensions.width),
            heightAnchor.constraint(equalToConstant: dimensions.height)
        ])
        return self
    }
    // pecker:ignore
    @discardableResult
    func equal(a d1: Dimensions, to d2: NSLayoutDimension, _ accessories: Accessories = .zero) -> Self {
        switch d1 {
            case .width:
                widthAnchor.constraint(equalTo: d2, multiplier: accessories.multiplier, constant: accessories.constant).isActive = true
            case .height:
                heightAnchor.constraint(equalTo: d2, multiplier: accessories.multiplier, constant: accessories.constant).isActive = true
        }
        return self
    }
    
    /// Set right or left constaints
    @discardableResult
    func align(a axis: HorizontalAxis, to a: NSLayoutXAxisAnchor, _ constant: CGFloat = 0.0) -> Self {
        switch axis {
            case .right:
                rightAnchor.constraint(equalTo: a, constant: -constant).isActive = true
            case .left:
                leftAnchor.constraint(equalTo: a, constant: constant).isActive = true
            case .trailing:
                trailingAnchor.constraint(equalTo: a, constant: -constant).isActive = true
            case .leading:
                leadingAnchor.constraint(equalTo: a, constant: constant).isActive = true
        }
        return self
    }
    
    @discardableResult
    func align(a axis: VerticalAxis, to a: NSLayoutYAxisAnchor, _ constant: CGFloat = 0.0) -> Self {
        switch axis {
            case .top:
                topAnchor.constraint(equalTo: a, constant: constant).isActive = true
            case .bottom:
                bottomAnchor.constraint(equalTo: a, constant: -constant).isActive = true
        }
        return self
    }
    
    /// Set one dimension
    @discardableResult
    func setDimensions(_ dimenType: Dimensions, _ size: CGFloat) -> Self {
        switch dimenType {
            case .height:
                heightAnchor.constraint(equalToConstant: size).isActive = true
            case .width:
                widthAnchor.constraint(equalToConstant: size).isActive = true
        }
        return self
    }
    
}

// MARK:- Style manipulation

extension UIView {
    
    @discardableResult
    func corners(_ radius: CGFloat = 8, style: CornerStyle = .all) -> Self {
        switch style {
            case .all:
                layer.maskedCorners = [
                    .layerMinXMinYCorner,
                    .layerMaxXMaxYCorner,
                    .layerMaxXMinYCorner,
                    .layerMinXMaxYCorner
            ]
            case .down:
                layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
            case .left:
                layer.maskedCorners = [.layerMinXMinYCorner, .layerMinXMaxYCorner]
            case .right:
                layer.maskedCorners = [.layerMaxXMinYCorner, .layerMaxXMaxYCorner]
            case .up:
                layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            case .upLeftDownRight:
                layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMaxYCorner]
            case .upRightDownLeft:
                layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMaxYCorner]
        }
        layer.cornerRadius = radius
        layer.masksToBounds = true
        return self
    }
    
    enum CornerStyle {
        case all, up, down, right, left, upLeftDownRight, upRightDownLeft
    }
    
    @discardableResult
    func border(width: CGFloat, color: UIColor) -> Self {
        layer.borderColor = color.cgColor
        layer.borderWidth = width
        return self
    }
    
    @discardableResult
    func shadow(offset: UIOffset, color: UIColor, radius: CGFloat, opacity: Float)  -> Self {
        layer.masksToBounds = false
        layer.shadowRadius = radius
        layer.shadowColor = color.cgColor
        layer.shadowOffset = .init(width: offset.horizontal, height: offset.vertical)
        layer.shadowOpacity = opacity
        return self
    }
    
    @discardableResult
    func background(_ color: UIColor?, animated: Bool = false) -> Self {
        if animated {
            UIView.animate(withDuration: 0.5) { self.backgroundColor = color }
        } else {
            self.backgroundColor = color
        }
        return self
    }
    
    @discardableResult
    func tint(_ color: UIColor) -> Self {
        tintColor = color
        return self
    }
    
    @discardableResult
    func hidden(_ hide: Bool) -> Self {
        UIView.animate(
            withDuration: 0.3,
            animations: {
                self.alpha = hide ? 0 : 1
        }) {  _ in
            self.isHidden = hide
        }
        return self
    }

    // pecker:ignore
    @discardableResult
    func opacity(_ value: CGFloat) -> Self {
        UIView.animate(withDuration: 0.5) { self.alpha = value }
        return self
    }
    
    @discardableResult
    func userInteraction(enabled: Bool) -> Self {
        isUserInteractionEnabled = enabled
        return self
    }
}

// MARK:- STACK VIEWS

extension UIStackView {
    
    func addArranged(_ views: UIView...) {
        views.forEach(addArrangedSubview)
    }
    
}
