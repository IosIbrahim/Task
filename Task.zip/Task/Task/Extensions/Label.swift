//
//  Label.swift
//  Task
//
//  Created by ibrahem on 24/07/2022.
//

import Foundation
import UIKit

// @IBDesignable
final class Label: UILabel {

    @IBInspectable
    var insets: UIEdgeInsets = UIEdgeInsets(top: 12, left: 8, bottom: 12, right: 8) {
        didSet {
            setNeedsDisplay()
            invalidateIntrinsicContentSize()
        }
    }
    
    override func drawText(in rect: CGRect) {
        super.drawText(in: rect.inset(by: insets))
    }
    
    override var intrinsicContentSize: CGSize {
        var contentSize = super.intrinsicContentSize
        contentSize.height += (insets.top + insets.bottom)
        contentSize.width += (insets.left + insets.right)
        return contentSize
    }
    
    @discardableResult
    func text(_ text: String) -> Label {
        self.text = text
        return self
    }
    
    @discardableResult
    func font(_ typeface: UIFont) -> Label {
        self.font = typeface
        return self
    }
    
    @discardableResult
    func foreground(_ color: UIColor) -> Label {
        self.textColor = color
        return self
    }
    
    @discardableResult
    func alignment(_ align: NSTextAlignment) -> Label {
        self.textAlignment = align
        return self
    }
    
    @discardableResult
    func padding(_ margins: UIEdgeInsets) -> Label {
        self.insets = margins
        return self
    }

}
