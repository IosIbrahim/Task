//
//  HomeViewModel.swift
//  Task
//
//  Created by ibrahem on 24/07/2022.
//

import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

protocol APIResponse {
    func fetchError(_ message:String)
    func fetchResponseData(_ response:Data)
}

class HomeViewModel:NSObject {
    
    var delegate: APIResponse?
    
    func getHeadline(_ page:Int) {
        let semaphore = DispatchSemaphore (value: 0)
        var request = URLRequest(url: URL(string: "https://newsapi.org/v2/top-headlines?q=headline&apiKey=862440d73e314734bc9de0db1be10fbc&page=\(page)")!,timeoutInterval: Double.infinity)
        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
          guard let data = data else {
            print(String(describing: error))
            self.delegate?.fetchError(error?.localizedDescription ?? "")
            semaphore.signal()
            return
          }
          print(String(data: data, encoding: .utf8) ?? "")
          self.delegate?.fetchResponseData(data)
          semaphore.signal()
        }
        task.resume()
        semaphore.wait()
    }
    
    
    func getHomeArticles(_ page:Int) {
        let semaphore = DispatchSemaphore (value: 0)
        var request = URLRequest(url: URL(string: "https://newsapi.org/v2/everything?q=bitcoin&apiKey=862440d73e314734bc9de0db1be10fbc&page=\(page)")!,timeoutInterval: Double.infinity)
        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
          guard let data = data else {
            print(String(describing: error))
            self.delegate?.fetchError(error?.localizedDescription ?? "")
            semaphore.signal()
            return
          }
          print(String(data: data, encoding: .utf8)!)
          self.delegate?.fetchResponseData(data)
          semaphore.signal()
        }

        task.resume()
        semaphore.wait()
    }
}
