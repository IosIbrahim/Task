//
//  HomeController.swift
//  Task
//
//  Created by ibrahem on 24/07/2022.
//

import UIKit

class HomeController: UIViewController {
    private let viewModel = HomeViewModel()
    private var dataSources = [Article]()
    private var page: Int = 1
    private var isMore:Bool = false
    
    @IBOutlet weak var tblAritcles: UITableView!
    @IBOutlet weak var search: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblAritcles.register(HomeCell.self)
        viewModel.delegate = self
        viewModel.getHomeArticles(page)
        // Do any additional setup after loading the view.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

// MARK:- TABLE VIEWS DELEGATE & DATA SOURCE FUNCTIONS
extension HomeController: APIResponse {
    func fetchError(_ message: String) {
        print(message)
    }
    
    func fetchResponseData(_ response: Data) {
        do {
            let decoder: JSONDecoder = .init()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let  model = try decoder.decode(HomeResponse.self, from: response)
            if model.totalResults == model.articles?.count ?? .zero {
                isMore = false
                self.dataSources.append(contentsOf: model.articles ?? [])
            }else {
                isMore = true
                self.dataSources.append(contentsOf: model.articles ?? [])
            }
            DispatchQueue.main.async {
                self.tblAritcles.reloadData()
            }
        } catch {
            print("Error: Trying to convert JSON data to string")
            print(error.localizedDescription)
        }
    }
}

// MARK:- TABLE VIEWS DELEGATE & DATA SOURCE FUNCTIONS

extension HomeController:UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int { 1 }
    
    func tableView(_ tableView: UITableView,numberOfRowsInSection section: Int) -> Int { dataSources.count }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeue(HomeCell.self, for: indexPath)
        cell.drawCell(dataSources[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = DetailsController()
        vc.article = dataSources[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? { .init() }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == dataSources.count - 1 {
            if isMore {
                page += 1
                self.viewModel.getHomeArticles(page)
            }
        }
    }
    
}
