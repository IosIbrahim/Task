//
//  HomeCell.swift
//  Task
//
//  Created by ibrahem on 24/07/2022.
//

import UIKit
import SDWebImage

class HomeCell: UITableViewCell {

    @IBOutlet weak var pickerShadow: UIView!
    @IBOutlet weak var lblDes: Label!
    @IBOutlet weak var lblDate: Label!
    @IBOutlet weak var lblAuther: Label!
    @IBOutlet weak var lblTitle: Label!
    @IBOutlet weak var imgArticle: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func drawCell(_ article:Article) {
        imgArticle.contentMode = .scaleAspectFit
        imgArticle.corners(imgArticle.midHeight, style: .all)
        lblDes.text = article.articleDescription
        lblDate.text = article.publishedAt
        lblTitle.text = article.title
        lblAuther.text = article.author
        imgArticle.sd_setImage(with: .init(string: article.urlToImage ?? ""), placeholderImage: .init(named: "home"))
        pickerShadow.shadow(offset: .zero, color: Colors.ColorGray, radius: 10, opacity: 0.5)
    }
}
