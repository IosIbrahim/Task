//
//  DetailsController.swift
//  Task
//
//  Created by ibrahem on 24/07/2022.
//

import UIKit
import SDWebImage

class DetailsController: UIViewController {
    
    var article: Article?
    
    @IBOutlet weak var lblDes: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblAuther: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgArticle: UIImageView!
    @IBOutlet weak var pickerShadow: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        drawData()
        self.navigationItem.title = "detail".localized
        // Do any additional setup after loading the view.
    }

    func drawData() {
        lblDes.text = "\("description".localized) \(article?.articleDescription ?? "")"
        lblDate.text = "\("date".localized) \(article?.publishedAt ?? "")"
        lblAuther.text = "\("auther".localized) \(article?.author ?? "")"
        lblTitle.text = "\("title".localized) \(article?.title ?? "")"
        imgArticle.sd_setImage(with: .init(string: article?.urlToImage ?? ""), placeholderImage: .init(named: "home"))
        pickerShadow.shadow(offset: .zero, color: Colors.ColorGray, radius: 10, opacity: 0.5)
    }

}

