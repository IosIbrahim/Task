//
//  ViewController.swift
//  Task
//
//  Created by ibrahem on 24/07/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        loadTabBar()
    }
    
    func loadTabBar() {
        let nav = BaseNavigationController(rootViewController: TabBarController())
        nav.navigationBar.isHidden = true
        nav.modalPresentationStyle = .fullScreen
        UIView().semanticContentAttribute = .forceLeftToRight
        self.present(nav, animated: true)
    }

}

