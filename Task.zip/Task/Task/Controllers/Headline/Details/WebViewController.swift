//
//  WebViewController.swift
//  Task
//
//  Created by ibrahem on 24/07/2022.
//

import UIKit
import WebKit

class WebViewController: UIViewController {
    var url: String = ""
    
    @IBOutlet weak var webView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "detail".localized
        let link = URL(string:url)!
        let request = URLRequest(url: link)
        webView.load(request)
        // Do any additional setup after loading the view.
    }


}
