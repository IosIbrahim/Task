//
//  HeadLineController.swift
//  Task
//
//  Created by ibrahem on 24/07/2022.
//

import UIKit

class HeadLineController: UIViewController {
    private let viewModel = HomeViewModel()
    private var dataSources = [Article]()
    private var page: Int = 1
    private var isMore:Bool = false
    
    @IBOutlet weak var clcAritcles: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        clcAritcles.register(HeadLineCell.self)
        viewModel.delegate = self
        viewModel.getHeadline(page)
        // Do any additional setup after loading the view.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
// MARK:- TABLE VIEWS DELEGATE & DATA SOURCE FUNCTIONS
extension HeadLineController: APIResponse {
    func fetchError(_ message: String) {
        print(message)
    }
    
    func fetchResponseData(_ response: Data) {
        do {
            let decoder: JSONDecoder = .init()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let  model = try decoder.decode(HomeResponse.self, from: response)
            if model.totalResults == model.articles?.count ?? .zero {
                isMore = false
                self.dataSources.append(contentsOf: model.articles ?? [])
            }else {
                isMore = true
                self.dataSources.append(contentsOf: model.articles ?? [])
            }
            DispatchQueue.main.async {
                self.clcAritcles.reloadData()
            }
        } catch {
            print("Error: Trying to convert JSON data to string")
            print(error.localizedDescription)
        }
    }
}

// MARK:- COLLECTION VIEWS DELEGATE & DATA SOURCE FUNCTIONS

extension HeadLineController: UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UICollectionViewDelegate {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int { 1 }
    
    func collectionView(_ collectionView: UICollectionView,
                                 numberOfItemsInSection section: Int) -> Int { dataSources.count }
    
    func collectionView(_ collectionView: UICollectionView,
                                 cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeue(HeadLineCell.self, for: indexPath)
        cell.drawCell(dataSources[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return .init(width: (collectionView.bounds.size.width) ,height: 120)
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat { 5 }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumInteritemSpacingForSectionAt section: Int) -> CGFloat { 5 }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return .init(top: 5, left: 5, bottom: 5, right: 5)
    }
    
    func collectionView(_ collectionView: UICollectionView,
                                 didSelectItemAt indexPath: IndexPath) {
        let vc = WebViewController()
        vc.url = dataSources[indexPath.row].url ?? ""
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if indexPath.row == dataSources.count - 1 {
            if isMore {
                page += 1
                self.viewModel.getHeadline(page)
            }
        }
    }
    
}
