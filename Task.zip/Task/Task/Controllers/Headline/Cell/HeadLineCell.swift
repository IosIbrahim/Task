//
//  HeadLineCell.swift
//  Task
//
//  Created by ibrahem on 24/07/2022.
//

import UIKit

class HeadLineCell: UICollectionViewCell {

    @IBOutlet weak var picker: UIView!
    @IBOutlet weak var lblAuther: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgArticle: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func drawCell(_ article:Article) {
        imgArticle.contentMode = .center
        imgArticle.corners(imgArticle.midHeight, style: .all)
        lblTitle.text = article.title
        lblAuther.text = article.author
        lblTitle.adjustsFontSizeToFitWidth = true
        imgArticle.sd_setImage(with: .init(string: article.urlToImage ?? ""), placeholderImage: .init(named: "home"))
        picker.shadow(offset: .zero, color: Colors.ColorGray, radius: 10, opacity: 0.5)
    }
}
