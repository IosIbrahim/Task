//
//  TabBarController.swift
//  Task
//
//  Created by Ibrahim Sabry on 24/07/2022.
//

import UIKit

class TabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        loadTabBarItems()
        // Do any additional setup after loading the view.
    }


    //MARK: - loadTabBarItems
    func loadTabBarItems(){
        let home = HomeController()
        home.tabBarItem.image = #imageLiteral(resourceName: "home")
        home.title  = "home".localized
      //  searchVC.navigationItem.titleView = imageView
        let nav = BaseNavigationController(rootViewController: home)
        
        let head = HeadLineController()
        head.tabBarItem.image = #imageLiteral(resourceName: "menu")
        head.title  = "headline".localized
        let nav2 = BaseNavigationController(rootViewController: head)
        viewControllers = [nav,nav2]
    }
    
    //MARK: - setupTabBarLayout
    func setupTabBarLayout(){
        tabBar.tintColor = Colors.ColorBlue
        tabBar.unselectedItemTintColor = UIColor.gray
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12)], for: .normal)
        
        tabBar.backgroundColor = UIColor.white
        tabBar.layer.masksToBounds = true
        tabBar.isTranslucent = true
        tabBar.barStyle = .default
        //tabBar.layer.cornerRadius = 20
        //tabBar.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        let appearance = UITabBarItem.appearance()
        let attributes = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12)]
        appearance.setTitleTextAttributes(attributes, for: .normal)
    }

}


extension String {
    var localized: String {
        return NSLocalizedString(self, comment: "")
    }
}
