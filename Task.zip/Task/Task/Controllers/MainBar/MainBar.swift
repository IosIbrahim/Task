//
//  MainBar.swift
//  Task
//
//  Created by Ibrahim Sabry on 24/07/2022.
//

import Foundation
import UIKit

class BaseNavigationController: UINavigationController {
    
    // MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationBar.backIndicatorImage = UIImage(named: "ic-back")
        navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "ic-back")
        navigationBar.barTintColor = Colors.ColorMain
        navigationBar.tintColor = .white
        navigationBar.isTranslucent = false
        navigationBar.barStyle = .black
        navigationBar.titleTextAttributes = [
            .foregroundColor: UIColor.white,
            .font: UIFont.boldSystemFont(ofSize: 18)
        ]
        if #available(iOS 15, *) {
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = Colors.ColorMain
            appearance.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            UINavigationBar.appearance().standardAppearance = appearance
            UINavigationBar.appearance().scrollEdgeAppearance = appearance
        }
        
    }
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        debugPrint("\(#function) at \(self)")
    }
    
    
    
    func removeBorder() {
        navigationBar.setValue(true, forKey: "hidesShadow")
    }
    
    func showBorder(){
        navigationBar.setValue(false, forKey: "hidesShadow")
    }
    
    func initializeNavigationBarAppearance(){
        // bacground color for nav
        navigationBar.barTintColor = Colors.ColorMain
        
        // colors for tint for items in nav
        navigationBar.tintColor =  .white
    }
    
    
    func setNavBarHandleForTransparent(){
        // handle navigation properties  -> make it Transparent wanted , this func base  handle for  makeNavigationTranslucent in base view controller if applied
        navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationBar.shadowImage = UIImage()
        view.backgroundColor = .clear
    }
    
}

import UIKit

struct Colors {
    static let ColorMain = UIColor(hexString: "3A1B50"),
    ColorBlue = UIColor(hexString: "03A9F4"),
    ColorAzure = UIColor(hexString: "F1F7F7"),
    ColorLightGray = UIColor(hexString: "8E8E93"),
    ColorGray = UIColor(hexString: "8B8B8B"),
    ColorAliceBlue = UIColor(hexString: "F5FAFC"),
    ColorOrange = UIColor(hexString: "FFA300"),
    ColorSolitude = UIColor(hexString: "EAEEF1"),
    ColorGreen = UIColor(hexString: "51CA8D"),
    ColorLondonHue = UIColor(hexString: "BF8FB5"),
    ColoRed = UIColor(hexString: "E95A59"),
    shadow = UIColor(hexString: "#001E5B"),
    borderBlue = UIColor(hexString: "#4B2E5F"),
    bordrGray = UIColor(hexString: "#EDEDED"),
    blueBorder = UIColor(hexString: "#E6EAEE")
}
